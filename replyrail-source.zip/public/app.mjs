import {STATES,validateOrder,parseBackup,moneyToUnits,rankOrders,metrics,updateOrder,followUp,demoOrders} from './domain.mjs';
const $=id=>document.getElementById(id), KEY='replyrail.v1';
const names={reply:'Awaiting reply',confirm:'Confirmation',ready:'Ready',complete:'Completed'};
let orders=[],selected=null,filter='open',storageBlocked=false;
const iconize=()=>window.lucide?.createIcons();
const notice=message=>{$('notice').textContent=message;$('notice').hidden=false;};
try {const raw=localStorage.getItem(KEY);if(raw){orders=parseBackup(raw);$('saved').textContent='Restored from local workspace';}}catch {storageBlocked=true;notice('Saved workspace could not be read. It has not been overwritten. Export current work before closing.');}
function persist() {
  if(storageBlocked){notice('Changes are in memory only; export a backup before closing.');return;}
  try{localStorage.setItem(KEY,JSON.stringify({version:1,orders}));$('saved').textContent=`Saved locally ${new Date().toLocaleTimeString()}`;}catch{storageBlocked=true;notice('Local storage unavailable. Changes are in memory only; export a backup before closing.');}
}
const localDate=t=>{const d=new Date(t);return new Date(t-d.getTimezoneOffset()*60000).toISOString().slice(0,16);};
const format=t=>new Date(t).toLocaleString([], {month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'});
function render() {
  const now=Date.now(),m=metrics(orders,now);$('open-count').textContent=m.open;$('overdue-count').textContent=m.overdue;$('today-count').textContent=m.dueToday;$('value-count').textContent=`BHD ${(m.value/1000).toFixed(3)}`;
  $('data-label').textContent=orders.length ? `${orders.length} orders${orders.some(o=>o.id.startsWith('demo-'))?' | Synthetic example data':''}`:'Empty workspace';
  const q=$('search').value.toLowerCase();const list=rankOrders(orders,now).filter(o=>(filter==='open'?o.status!=='complete':o.status===filter)&&`${o.customer} ${o.item} ${o.action}`.toLowerCase().includes(q));
  $('orders').replaceChildren();$('empty').hidden=list.length>0;
  for(const o of list){const row=document.createElement('tr');row.classList.toggle('selected',o.id===selected);const first=document.createElement('td'),b=document.createElement('button'),sub=document.createElement('span');b.className='order-button';b.textContent=`${o.customer} / ${o.item}`;b.onclick=()=>openDetail(o.id);sub.className='subtext';sub.textContent=o.action;first.append(b,sub);const status=document.createElement('td'),badge=document.createElement('span');badge.className=`badge ${o.status}`;badge.textContent=names[o.status];status.append(badge);const due=document.createElement('td');due.textContent=format(o.due);due.className=o.status!=='complete'&&o.due<now?'late':'';const value=document.createElement('td');value.textContent=`${(o.amount/1000).toFixed(3)} BHD`;row.append(first,status,due,value);$('orders').append(row);}
  iconize();
}
function openDetail(id){selected=id;const o=orders.find(o=>o.id===id);if(!o)return;$('detail').hidden=false;$('detail-title').textContent=o.customer;$('detail-item').textContent=o.item;$('detail-status').value=o.status;$('detail-action').value=o.action;$('detail-due').value=localDate(o.due);$('draft').value=followUp(o);$('history').replaceChildren();for(const e of [...o.history].reverse()){const li=document.createElement('li');li.textContent=`${format(e.at)}: ${e.action}`;$('history').append(li);}render();}
function loadDemo(){if(orders.length && !confirm('Replace this local workspace with synthetic examples? Export a backup first.'))return;orders=demoOrders(Date.now());selected=null;$('detail').hidden=true;persist();render();}
$('demo').onclick=loadDemo;$('demo-footer').onclick=loadDemo;
$('search').oninput=render;
for(const b of document.querySelectorAll('[data-filter]'))b.onclick=()=>{filter=b.dataset.filter;document.querySelectorAll('[data-filter]').forEach(x=>x.classList.toggle('active',x===b));render();};
$('new').onclick=()=>{$('new-form').reset();$('new-form').elements.due.value=localDate(Date.now()+3600000);$('form-error').textContent='';$('new-dialog').showModal();};
$('cancel').onclick=()=>$('new-dialog').close();
$('new-form').onsubmit=e=>{e.preventDefault();try{if(orders.length>=1000)throw new Error('Workspace limit reached; export and archive completed orders.');const f=new FormData(e.target),now=Date.now();const order=validateOrder({id:crypto.randomUUID(),customer:f.get('customer'),item:f.get('item'),status:f.get('status'),action:f.get('action'),amount:moneyToUnits(f.get('amount')),due:new Date(f.get('due')).getTime(),created:now,history:[{at:now,action:'Order created'}]});orders.push(order);persist();$('new-dialog').close();openDetail(order.id);}catch(error){$('form-error').textContent=error.message;}};
$('save').onclick=()=>{try{const i=orders.findIndex(o=>o.id===selected);if(i<0)return;orders[i]=updateOrder(orders[i],{status:$('detail-status').value,action:$('detail-action').value,due:new Date($('detail-due').value).getTime()},Date.now());persist();openDetail(selected);}catch(error){notice(error.message);}};
$('close-detail').onclick=()=>{selected=null;$('detail').hidden=true;render();};
$('copy').onclick=async()=>{try{await navigator.clipboard.writeText($('draft').value);notice('Draft copied. No message was sent.');}catch{notice('Clipboard unavailable. Select and copy the draft manually.');}};
$('export').onclick=()=>{const url=URL.createObjectURL(new Blob([JSON.stringify({version:1,orders},null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download=`replyrail-${new Date().toISOString().slice(0,10)}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);};
$('import').onclick=()=>$('backup-file').click();
$('backup-file').onchange=async e=>{const file=e.target.files?.[0];try{if(!file)return;if(file.size>2000000)throw new Error('Backup exceeds 2 MB.');const incoming=parseBackup(await file.text());if(!confirm(`Replace workspace with ${incoming.length} backup orders? Export current orders first.`))return;orders=incoming;selected=null;$('detail').hidden=true;persist();render();notice('Backup restored.');}catch(error){notice(`Import refused; current orders are unchanged. ${error.message}`);}finally{e.target.value='';}};
render();setInterval(render,60000);
