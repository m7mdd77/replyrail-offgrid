export const STATES = ['reply', 'confirm', 'ready', 'complete'];
const text = (v,max) => typeof v === 'string' && v.trim().length > 0 && v.length <= max;
export function validateOrder(o) {
  if (!o || typeof o !== 'object' || Array.isArray(o) || !text(o.id,80) || !text(o.customer,80) || !text(o.item,120) || !text(o.action,200) || !STATES.includes(o.status) || !Number.isSafeInteger(o.amount) || o.amount < 0 || o.amount > 100000000 || !Number.isSafeInteger(o.due) || o.due < 0 || o.due > 8640000000000000 || !Number.isSafeInteger(o.created) || o.created < 0 || o.created > 8640000000000000 || !Array.isArray(o.history) || o.history.length > 1000 || o.history.some(e => !e || !text(e.action,250) || !Number.isSafeInteger(e.at) || e.at < 0 || e.at > 8640000000000000)) throw new Error('Invalid order: check fields, dates, amounts and history.');
  return {id:o.id,customer:o.customer.trim(),item:o.item.trim(),action:o.action.trim(),status:o.status,amount:o.amount,due:o.due,created:o.created,history:o.history.map(e=>({action:e.action,at:e.at}))};
}
export function parseBackup(raw) {
  if (typeof raw !== 'string' || raw.length > 2000000) throw new Error('Backup exceeds 2 MB.');
  const data = JSON.parse(raw);
  if (data?.version !== 1 || !Array.isArray(data.orders) || data.orders.length > 1000) throw new Error('Expected a version 1 ReplyRail backup.');
  const orders = data.orders.map(validateOrder);
  if (new Set(orders.map(o=>o.id)).size !== orders.length) throw new Error('Duplicate order IDs.');
  return orders;
}
export function moneyToUnits(value) {
  if (!/^\d{1,6}(\.\d{1,3})?$/.test(value)) throw new Error('Use a non-negative BHD amount with up to 3 decimal places.');
  const [a,b=''] = value.split('.');
  const units = Number(a) * 1000 + Number(b.padEnd(3,'0'));
  if (units > 100000000) throw new Error('Amount exceeds BHD 100,000.');
  return units;
}
export function rankOrders(orders,now) {
  return [...orders].sort((a,b) => Number(a.status === 'complete') - Number(b.status === 'complete') || a.due-b.due || a.created-b.created || a.id.localeCompare(b.id));
}
export function metrics(orders,now) {
  const open=orders.filter(o=>o.status!=='complete');
  return {open:open.length,overdue:open.filter(o=>o.due<now).length,dueToday:open.filter(o=>o.due>=now && o.due<now+86400000).length,value:open.reduce((s,o)=>s+o.amount,0)};
}
export function updateOrder(order,changes,now) {
  if (order.history.length >= 1000) throw new Error('History limit reached; export this order before creating a new one.');
  const updated = validateOrder({...order,...changes, id:order.id,created:order.created,history:[...order.history,{at:now,action:`Updated: ${changes.status ?? order.status}; ${changes.action ?? order.action}`} ]});
  return updated;
}
export function followUp(order) {
  return `Hi ${order.customer}, following up on ${order.item}. Next step: ${order.action}. Please let me know when convenient. Thank you.`;
}
export function demoOrders(now) {
  return [
    ['demo-1','Customer A','Weekend cake','Confirm pickup time','confirm',18500,-3],
    ['demo-2','Customer B','Handmade gift set','Reply with available colours','reply',12000,-1],
    ['demo-3','Customer C','Lunch order','Prepare pickup confirmation','ready',9000,2],
    ['demo-4','Customer D','Event cookies','Confirm quantity and date','confirm',24000,24],
    ['demo-5','Customer E','Gift wrapping','Order collected','complete',6000,-24],
  ].map(([id,customer,item,action,status,amount,hours])=>validateOrder({id,customer,item,action,status,amount,due:now+hours*3600000,created:now-86400000,history:[{at:now-86400000,action:'Synthetic demo order created'}]}));
}
