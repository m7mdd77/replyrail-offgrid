import http from 'node:http';
import {readFile} from 'node:fs/promises';
const routes = new Map([['/', ['public/index.html', 'text/html']], ['/app.mjs', ['public/app.mjs', 'text/javascript']], ['/domain.mjs', ['public/domain.mjs', 'text/javascript']], ['/style.css', ['public/style.css', 'text/css']], ['/icons.js', ['node_modules/lucide/dist/umd/lucide.js', 'text/javascript']]]);
const port = Number(process.env.PORT || 3240);
const server = http.createServer(async (req,res) => {
  const host = req.headers.host;
  if (host !== `127.0.0.1:${port}` && host !== `localhost:${port}`) {res.writeHead(403);res.end('Invalid host');return;}
  if (req.method !== 'GET' && req.method !== 'HEAD') {res.writeHead(405);res.end();return;}
  const route = routes.get(new URL(req.url, `http://${host}`).pathname);
  if (!route) {res.writeHead(404);res.end();return;}
  try {
    const body = await readFile(new URL(route[0], import.meta.url));
    res.writeHead(200, {'Content-Type':`${route[1]}; charset=utf-8`, 'X-Content-Type-Options':'nosniff', 'Referrer-Policy':'no-referrer', 'Cache-Control':'no-store', 'Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'none'; object-src 'none'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'"});
    res.end(req.method === 'HEAD' ? undefined : body);
  } catch {res.writeHead(500);res.end('Local asset unavailable. Run npm ci.');}
});
server.listen(port, '127.0.0.1', () => console.log(`ReplyRail: http://127.0.0.1:${port}`));
